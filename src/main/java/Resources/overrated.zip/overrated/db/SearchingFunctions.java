/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.overrated.db;

import java.util.Scanner;
import java.util.StringTokenizer;


public class SearchingFunctions {
    Scanner scannerStream ;
    String[] entries  ;
    int entriesLength ; 
    SearchingFunctions(Scanner _scannerStream ){
        entries = new  String[1000];
        scannerStream = _scannerStream ;
        entriesLength = 0 ;
        while(scannerStream.hasNext()){
            entries[entriesLength] = scannerStream.nextLine();
            entriesLength ++ ;
        }
    }
    String[] search(String key){
        //binary search
        String userName = "N/A1@2" ;
        String password = "N/A";
        int first = 0 ;
        StringTokenizer str ;
        int last   = entriesLength ;
        int middle = first + last / 2;
        while (first < last ){
            str = new StringTokenizer(entries[middle], "|"); //name and passwords are separted by   | , its illegal for user to write this charchter in user name
            
            String potenialUser = str.nextToken().trim();
            if ( potenialUser.equals(key)){ //name == name
                userName = potenialUser ;
                password = str.nextToken().trim();
                break ; //end the while
            }else if (entries[middle].compareTo(key) > 0){//go to left
                first = middle + 1 ;

            }else {//go to right
                last = middle -1 ;
            }
             middle = first + last / 2;
        }
        String[] returno ={userName , password} ; 
        return  returno ;
    }
    
    //0 succsess
    //error codes
    //-1 user alerady exists
    int addSorted(String userName , String hashedPassword){
        String[] result =search(userName);
        if  (result[0].equals(userName)){
            System.out.println("User alerady exists");
            return -1;
        }
       
        //---------------------TODO------------------------------
   
   int first = 0 ;
   int last = entriesLength - 1 ;
   int middle = (first + last)/2 ;
   boolean found = false ;
   //check for list
        entries[0] = userName + " | " + hashedPassword ;
        

   while (first <=last &&!found){
        middle = (first + last)/2 ;
        StringTokenizer str = new StringTokenizer(entries[middle], " | ");
        if (entries[middle].compareTo(userName) > 0){//go left
            first = middle +1 ;
        }else{ //go right
            last = middle -1 ;
        }

   }//now no duplicate

        //pointer is at previous middle
        if (entries[middle].compareTo(userName) > 0){ //neeed to be checcccked
            middle ++ ;
        }
        //insertAt(middle,item);

         return 0 ;
    }
}
