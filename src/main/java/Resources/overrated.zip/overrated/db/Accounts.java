
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.overrated.db;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ziad asem
 */
public class Accounts {
     Scanner scan = null ;
     String userName ;
     SearchingFunctions searchingFunctions;
     public Accounts(){
        
         try {
            Scanner scan  = new Scanner(new File("accounts.txt"));
            searchingFunctions = new SearchingFunctions(scan);
         } catch (FileNotFoundException ex) {
             System.out.println("No Such file");
             Logger.getLogger(Accounts.class.getName()).log(Level.SEVERE, null, ex);
         }
             
    }
    
    public boolean signIn(String name, String password){
         try {
             Scanner scan = new Scanner (new File (name));
              } catch (FileNotFoundException ex) {
             Logger.getLogger(Accounts.class.getName()).log(Level.SEVERE, null, ex);
         }
             //---------------------TO DO ADD FILES EXCEPTION
             String[] accountInfo = searchingFunctions.search(name);
             if (accountInfo[0] == "N/A1@2"){ //user not found
                 System.out.println("user not found");
                 return false ;
             }
             userName = accountInfo[0];                    
             return  accountInfo[1].equals(Hashing.hash(password));
        
    }


}
